package app.praymate

object PrayerContent {

    data class Topic(val key: String, val label: String, val refs: List<String>, val line: String)

    val topics = listOf(
        Topic("money", "Money & provision", listOf("Philippians 4:19", "Matthew 6:31–33"),
            "You know what I need before I ask. Teach me to work with wisdom, give with joy, and trust You to supply."),
        Topic("work", "Work, business or career", listOf("Colossians 3:23", "Proverbs 16:3"),
            "I place my work in Your hands. Give me skill, honesty and favor, and help me do everything as if it were for You."),
        Topic("family", "Family", listOf("Joshua 24:15", "Psalm 127:1"),
            "Watch over my family. Build our home on Your peace, and help me love the people closest to me well."),
        Topic("future", "My future & direction", listOf("Jeremiah 29:11", "Proverbs 3:5–6"),
            "I cannot see what is ahead, but You can. Lead me one step at a time and make my path clear."),
        Topic("safety", "Safety & protection", listOf("Psalm 91:1–2", "Psalm 4:8"),
            "Cover me and the people I love today. Keep us safe where we go and in everything we do."),
        Topic("anxiety", "Anxiety & uncertainty", listOf("Philippians 4:6–7", "1 Peter 5:7"),
            "I hand You every worry I am holding. Replace my fear with Your peace."),
        Topic("god", "My relationship with God", listOf("James 4:8", "Psalm 42:1"),
            "I want to know You more, not just ask You for things. Draw me close and make my heart soft toward You."),
        Topic("discipline", "Discipline & consistency", listOf("Galatians 6:9", "2 Timothy 1:7"),
            "Give me strength to keep showing up, even on the days I do not feel like it. Make me steady, not perfect.")
    )

    /** Apps shown first in the app picker. */
    val popular = setOf(
        "com.instagram.android", "com.zhiliaoapp.musically", "com.ss.android.ugc.trill",
        "com.facebook.katana", "com.whatsapp", "com.google.android.youtube",
        "com.snapchat.android", "com.twitter.android", "org.telegram.messenger"
    )

    fun build(name: String, selected: Set<String>): Pair<List<String>, List<String>> {
        val chosen = topics.filter { selected.contains(it.key) }.ifEmpty { topics.filter { it.key == "god" } }.take(3)
        val paras = ArrayList<String>()
        val who = if (name.isBlank()) "" else ", $name"
        paras.add("Father, I come to You as I am$who. Before anything else, I stop to put You first.")
        chosen.forEach { paras.add(it.line) }
        paras.add("I choose faith over fear today. In Jesus' name, amen.")
        val refs = chosen.flatMap { it.refs }.distinct().take(4)
        return Pair(paras, refs)
    }
}
