package app.praymate

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class PrayerService : AccessibilityService() {

    private lateinit var prefs: Prefs
    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private var overlay: View? = null
    private var overlayFor: String? = null
    private var lastPkg: String? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        prefs = Prefs(this)
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName || pkg == "com.android.systemui") return
        if (isKeyboard(pkg)) return

        val cameFromElsewhere = pkg != lastPkg
        lastPkg = pkg

        // User left for another app or the home screen: drop the overlay.
        if (overlay != null && pkg != overlayFor) removeOverlay()

        if (!prefs.enabled || !prefs.apps.contains(pkg)) return
        if (overlay != null) return
        if (!cameFromElsewhere) return

        val graceMs = prefs.graceMinutes * 60_000L
        if (System.currentTimeMillis() - prefs.lastHandled(pkg) < graceMs) return

        showOverlay(pkg)
    }

    override fun onInterrupt() {
        removeOverlay()
    }

    override fun onDestroy() {
        removeOverlay()
        super.onDestroy()
    }

    private fun isKeyboard(pkg: String): Boolean {
        return try {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.enabledInputMethodList.any { it.packageName == pkg }
        } catch (ex: Exception) {
            false
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun label(pkg: String): String {
        return try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (ex: Exception) {
            "this app"
        }
    }

    private fun text(ctx: Context, t: String, sp: Float, bold: Boolean, alpha: Float): TextView {
        val v = TextView(ctx)
        v.text = t
        v.textSize = sp
        v.setTextColor(Color.WHITE)
        v.alpha = alpha
        if (bold) v.typeface = Typeface.DEFAULT_BOLD
        v.setLineSpacing(0f, 1.25f)
        v.setPadding(0, dp(6), 0, dp(10))
        return v
    }

    private fun showOverlay(pkg: String) {
        val ctx: Context = this
        val (paras, refs) = PrayerContent.build(prefs.name, prefs.topics)

        val root = object : FrameLayout(ctx) {
            override fun dispatchKeyEvent(event: KeyEvent): Boolean {
                if (event.keyCode == KeyEvent.KEYCODE_BACK) {
                    if (event.action == KeyEvent.ACTION_UP) {
                        removeOverlay()
                        performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
                    }
                    return true
                }
                return super.dispatchKeyEvent(event)
            }
        }
        root.setBackgroundColor(Color.parseColor("#1B2A7A"))
        root.isFocusable = true
        root.isFocusableInTouchMode = true

        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(24), dp(72), dp(24), dp(32))
        col.addView(text(ctx, "Before you open " + label(pkg), 28f, true, 1f))
        paras.forEach { col.addView(text(ctx, it, 18f, false, 0.95f)) }
        col.addView(text(ctx, refs.joinToString("   ·   "), 14f, false, 0.7f))

        val amen = Button(ctx)
        amen.isAllCaps = false
        amen.isEnabled = false
        amen.alpha = 0.5f
        amen.text = "Take a breath…"
        amen.setTextColor(Color.parseColor("#1B2A7A"))
        amen.setBackgroundColor(Color.WHITE)
        amen.setOnClickListener {
            prefs.markPrayed()
            prefs.setHandledNow(pkg)
            removeOverlay()
        }
        handler.postDelayed({
            amen.isEnabled = true
            amen.alpha = 1f
            amen.text = "Amen, I have prayed"
        }, 3000)

        val skip = Button(ctx)
        skip.isAllCaps = false
        skip.text = "Skip for now"
        skip.setTextColor(Color.WHITE)
        skip.setBackgroundColor(Color.TRANSPARENT)
        skip.setOnClickListener {
            prefs.setHandledNow(pkg)
            removeOverlay()
        }

        val btnLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        btnLp.topMargin = dp(20)
        col.addView(amen, btnLp)
        col.addView(skip, LinearLayout.LayoutParams(btnLp))

        val sv = ScrollView(ctx)
        sv.addView(col)
        root.addView(sv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.OPAQUE
        )
        try {
            wm.addView(root, lp)
            overlay = root
            overlayFor = pkg
            root.requestFocus()
        } catch (ex: Exception) {
            overlay = null
            overlayFor = null
        }
    }

    private fun removeOverlay() {
        overlay?.let {
            try {
                wm.removeView(it)
            } catch (ex: Exception) {
            }
        }
        overlay = null
        overlayFor = null
    }
}
