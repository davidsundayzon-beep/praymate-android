package app.praymate

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds

class MainActivity : Activity() {

    private lateinit var prefs: Prefs
    private var screen = "home"

    private val blue = Color.parseColor("#2338A8")
    private val ink = Color.parseColor("#141B3D")
    private val bg = Color.parseColor("#F6F7FB")
    private val match = ViewGroup.LayoutParams.MATCH_PARENT
    private val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

    // TEST banner unit. Replace with your own AdMob banner unit id before release.
    private val bannerUnit = "ca-app-pub-3940256099942544/6300978111"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        MobileAds.initialize(this)
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (screen != "home") {
            screen = "home"
            render()
        } else {
            super.onBackPressed()
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun tv(t: String, sp: Float = 16f, bold: Boolean = false, color: Int = ink): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = sp
        v.setTextColor(color)
        if (bold) v.typeface = Typeface.DEFAULT_BOLD
        v.setPadding(0, dp(4), 0, dp(4))
        return v
    }

    private fun btn(t: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.isAllCaps = false
        b.textSize = 16f
        b.setTextColor(Color.WHITE)
        b.setBackgroundColor(blue)
        b.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(match, wrap)
        lp.topMargin = dp(12)
        b.layoutParams = lp
        return b
    }

    private fun serviceEnabled(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return s.contains(packageName) && s.contains("PrayerService")
    }

    private fun render() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(bg)

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(40), dp(20), dp(20))

        val scroll = ScrollView(this)
        scroll.addView(col)
        root.addView(scroll, LinearLayout.LayoutParams(match, 0, 1f))

        when (screen) {
            "apps" -> buildApps(col)
            "topics" -> buildTopics(col)
            else -> {
                buildHome(col)
                root.addView(banner())
            }
        }
        setContentView(root)
    }

    private fun banner(): View {
        val v = AdView(this)
        v.setAdSize(AdSize.BANNER)
        v.adUnitId = bannerUnit
        v.loadAd(AdRequest.Builder().build())
        return v
    }

    private fun buildHome(col: LinearLayout) {
        col.addView(tv("PrayMate", 34f, true))
        col.addView(tv("Pray before you scroll.", 16f, false, Color.GRAY))

        val n = prefs.streak()
        val dayWord = if (n == 1) "day" else "days"
        col.addView(tv("$n $dayWord in a row", 22f, true))

        val active = serviceEnabled()
        col.addView(
            tv(
                if (active) "Active. A prayer appears before your chosen apps."
                else "Not active yet. Turn PrayMate on in Accessibility settings.",
                15f
            )
        )
        if (!active) col.addView(btn("Turn on PrayMate") { disclosure() })

        val nameBox = EditText(this)
        nameBox.hint = "Your first name"
        nameBox.setText(prefs.name)
        nameBox.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { prefs.name = s?.toString()?.trim() ?: "" }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
        col.addView(nameBox)

        val sw = Switch(this)
        sw.text = "Prayer before apps"
        sw.isChecked = prefs.enabled
        sw.setOnCheckedChangeListener { _, c -> prefs.enabled = c }
        sw.setPadding(0, dp(12), 0, dp(12))
        col.addView(sw)

        col.addView(btn("Choose apps (${prefs.apps.size})") { screen = "apps"; render() })
        col.addView(btn("Choose what to pray for (${prefs.topics.size})") { screen = "topics"; render() })

        val graceBtn = btn("Don't ask again for: ${prefs.graceMinutes} min") {}
        graceBtn.setOnClickListener {
            val options = listOf(1, 5, 15, 30)
            val next = options[(options.indexOf(prefs.graceMinutes) + 1) % options.size]
            prefs.graceMinutes = next
            graceBtn.text = "Don't ask again for: $next min"
        }
        col.addView(graceBtn)

        col.addView(btn("Preview a prayer") {
            val (paras, refs) = PrayerContent.build(prefs.name, prefs.topics)
            AlertDialog.Builder(this)
                .setTitle("Your prayer")
                .setMessage(paras.joinToString("\n\n") + "\n\n" + refs.joinToString("  ·  "))
                .setPositiveButton("Close", null)
                .show()
        })
    }

    private fun disclosure() {
        AlertDialog.Builder(this)
            .setTitle("Before you turn this on")
            .setMessage(
                "PrayMate uses Android's Accessibility Service for one purpose: to know when you open an app you chose, so it can show a prayer first.\n\n" +
                "PrayMate does not read your screen, messages or passwords, and it does not record what you do inside other apps. Ads appear only on PrayMate's own home screen."
            )
            .setPositiveButton("Continue") { _, _ -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
            .setNegativeButton("Not now", null)
            .show()
    }

    private fun buildApps(col: LinearLayout) {
        col.addView(tv("Choose apps", 28f, true))
        col.addView(tv("PrayMate opens first when you launch these.", 15f, false, Color.GRAY))
        col.addView(btn("Done") { screen = "home"; render() })

        val selected = prefs.apps.toMutableSet()
        val pm = packageManager
        val launch = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = pm.queryIntentActivities(launch, 0)
            .map { Pair(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedWith(
                compareByDescending<Pair<String, String>> { PrayerContent.popular.contains(it.first) }
                    .thenBy { it.second.lowercase() }
            )

        for ((pkg, label) in list) {
            val cb = CheckBox(this)
            cb.text = label
            cb.textSize = 17f
            cb.isChecked = selected.contains(pkg)
            cb.setPadding(dp(8), dp(10), 0, dp(10))
            cb.setOnCheckedChangeListener { _, c ->
                if (c) selected.add(pkg) else selected.remove(pkg)
                prefs.apps = selected
            }
            col.addView(cb)
        }
    }

    private fun buildTopics(col: LinearLayout) {
        col.addView(tv("What is on your heart?", 28f, true))
        col.addView(tv("Choose up to 3. Your prayers follow them.", 15f, false, Color.GRAY))
        col.addView(btn("Done") { screen = "home"; render() })

        val selected = prefs.topics.toMutableSet()
        for (t in PrayerContent.topics) {
            val cb = CheckBox(this)
            cb.text = t.label
            cb.textSize = 17f
            cb.isChecked = selected.contains(t.key)
            cb.setPadding(dp(8), dp(10), 0, dp(10))
            cb.setOnCheckedChangeListener { buttonView, c ->
                if (c) {
                    if (selected.size >= 3) {
                        buttonView.isChecked = false
                        Toast.makeText(this, "You can choose up to 3.", Toast.LENGTH_SHORT).show()
                    } else {
                        selected.add(t.key)
                    }
                } else {
                    selected.remove(t.key)
                }
                prefs.topics = selected
            }
            col.addView(cb)
        }
    }
}
