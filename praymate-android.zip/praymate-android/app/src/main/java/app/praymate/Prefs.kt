package app.praymate

import android.content.Context
import java.time.LocalDate

class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("praymate", Context.MODE_PRIVATE)

    var name: String
        get() = sp.getString("name", "") ?: ""
        set(v) { sp.edit().putString("name", v).apply() }

    var enabled: Boolean
        get() = sp.getBoolean("enabled", true)
        set(v) { sp.edit().putBoolean("enabled", v).apply() }

    var graceMinutes: Int
        get() = sp.getInt("grace", 5)
        set(v) { sp.edit().putInt("grace", v).apply() }

    var apps: Set<String>
        get() = HashSet(sp.getStringSet("apps", emptySet()) ?: emptySet())
        set(v) { sp.edit().putStringSet("apps", HashSet(v)).apply() }

    var topics: Set<String>
        get() = HashSet(sp.getStringSet("topics", emptySet()) ?: emptySet())
        set(v) { sp.edit().putStringSet("topics", HashSet(v)).apply() }

    private var days: Set<String>
        get() = HashSet(sp.getStringSet("days", emptySet()) ?: emptySet())
        set(v) { sp.edit().putStringSet("days", HashSet(v)).apply() }

    fun markPrayed() {
        days = days + LocalDate.now().toString()
    }

    fun streak(): Int {
        val set = days
        var d = LocalDate.now()
        if (!set.contains(d.toString())) d = d.minusDays(1)
        var n = 0
        while (set.contains(d.toString())) {
            n++
            d = d.minusDays(1)
        }
        return n
    }

    fun lastHandled(pkg: String): Long = sp.getLong("t_$pkg", 0L)

    fun setHandledNow(pkg: String) {
        sp.edit().putLong("t_$pkg", System.currentTimeMillis()).apply()
    }
}
